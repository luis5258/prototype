create table t_paises (id int auto_increment,
						nombre varchar(100),
                        primary key(id));
                        
insert into t_paises (nombre) values ('MEXICO'),('BRASIL'),
								     ('INGLATERRA'),('URUGUAY'),
									 ('ARGENTINA'),('PANAMA'),
                                     ('BELGICA'),('CANADA');
